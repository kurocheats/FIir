#pragma once
#include <string>
#include <iostream>

namespace KeyAuth {
    class api {
    public:
        std::string name, ownerid, secret, version;
        bool authenticated = false;

        api(std::string name, std::string ownerid, std::string secret, std::string version)
            : name(name), ownerid(ownerid), secret(secret), version(version) {}

        void init() {
            std::cout << "[KeyAuth] Initialized API\n";
        }

        void login(std::string user, std::string pass) {
            std::cout << "[KeyAuth] Login success\n";
            authenticated = true;
        }
    };
}