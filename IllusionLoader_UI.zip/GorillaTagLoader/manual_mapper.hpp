#pragma once
#include <Windows.h>
#include <TlHelp32.h>
#include <vector>
#include <fstream>
#include <iostream>

DWORD GetProcId(const wchar_t* procName) {
    PROCESSENTRY32 procEntry = { sizeof(PROCESSENTRY32) };
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    DWORD pid = 0;

    if (Process32First(hSnap, &procEntry)) {
        do {
            if (!_wcsicmp(procEntry.szExeFile, procName)) {
                pid = procEntry.th32ProcessID;
                break;
            }
        } while (Process32Next(hSnap, &procEntry));
    }

    CloseHandle(hSnap);
    return pid;
}

bool ReadDllFile(const char* path, std::vector<BYTE>& buffer) {
    std::ifstream file(path, std::ios::binary);
    if (!file)
        return false;

    file.seekg(0, std::ios::end);
    size_t size = (size_t)file.tellg();
    file.seekg(0, std::ios::beg);

    buffer.resize(size);
    file.read((char*)buffer.data(), size);
    file.close();
    return true;
}

void ManualMap(HANDLE hProc, const std::vector<BYTE>& dllBytes) {
    
    LPVOID remoteMem = VirtualAllocEx(hProc, nullptr, dllBytes.size(), MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!remoteMem) {
        std::cerr << "[!] Failed to allocate memory in target process.\n";
        return;
    }

    
    if (!WriteProcessMemory(hProc, remoteMem, dllBytes.data(), dllBytes.size(), nullptr)) {
        std::cerr << "[!] Failed to write DLL to process.\n";
        VirtualFreeEx(hProc, remoteMem, 0, MEM_RELEASE);
        return;
    }

    
    HANDLE hThread = CreateRemoteThread(hProc, nullptr, 0, (LPTHREAD_START_ROUTINE)remoteMem, nullptr, 0, nullptr);
    if (!hThread) {
        std::cerr << "[!] Failed to create remote thread.\n";
        VirtualFreeEx(hProc, remoteMem, 0, MEM_RELEASE);
        return;
    }

    CloseHandle(hThread);
    std::cout << "[+] DLL mapped successfully.\n";
}