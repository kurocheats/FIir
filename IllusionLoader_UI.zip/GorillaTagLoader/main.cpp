
#include <iostream>
#include <windows.h>
#include <string>
#include <chrono>
#include <thread>
#include "keyauth.hpp"
#include "manual_mapper.hpp"

using namespace std;

KeyAuth::api keyauthApp(
    "YourAppName",
    "YourOwnerId",
    "YourAppSecret",
    "1.0"
);

void SlowPrint(const string& text, int delay = 30) {
    for (char c : text) {
        cout << c << flush;
        this_thread::sleep_for(chrono::milliseconds(delay));
    }
    cout << endl;
}

void SetColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

void ShowHeader() {
    system("cls");
    SetColor(11); // Light cyan
    SlowPrint("  Illusion Loader v1.0", 15);
    SetColor(8);  // Dark gray
    SlowPrint("  Space-Inspired Gorilla Tag Mod Loader\n", 15);
    SetColor(7);  // Default
}

int main() {
    ShowHeader();
    string user, pass;

    SetColor(10); // Green
    cout << "\n[+] Username: ";
    SetColor(7);
    cin >> user;
    SetColor(10);
    cout << "[+] Password: ";
    SetColor(7);
    cin >> pass;

    keyauthApp.init();
    keyauthApp.login(user, pass);

    if (!keyauthApp.authenticated) {
        SetColor(12); // Red
        cout << "\n[!] Authentication failed." << endl;
        return 1;
    }

    ShowHeader();
    SetColor(11);
    SlowPrint("[+] Authentication successful.", 25);

    wstring procName = L"GorillaTag.exe";
    DWORD pid = GetProcId(procName.c_str());

    if (!pid) {
        SetColor(12);
        cout << "[!] Gorilla Tag is not running." << endl;
        return 1;
    }

    HANDLE hProc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (!hProc) {
        SetColor(12);
        cout << "[!] Failed to open Gorilla Tag process." << endl;
        return 1;
    }

    string dllPath;
    SetColor(10);
    cout << "[>] Enter path to your DLL: ";
    SetColor(7);
    cin >> dllPath;

    vector<BYTE> dllBuffer;
    if (!ReadDllFile(dllPath.c_str(), dllBuffer)) {
        SetColor(12);
        cout << "[!] Failed to read DLL file." << endl;
        return 1;
    }

    SetColor(11);
    cout << "[*] Injecting..." << flush;
    this_thread::sleep_for(chrono::milliseconds(500));
    cout << "." << flush;
    this_thread::sleep_for(chrono::milliseconds(500));
    cout << "." << flush;
    this_thread::sleep_for(chrono::milliseconds(500));
    cout << "." << endl;

    ManualMap(hProc, dllBuffer);
    CloseHandle(hProc);

    SetColor(10);
    cout << "\n[+] DLL injection complete. Enjoy Gorilla Tag!" << endl;
    SetColor(7);
    return 0;
}
